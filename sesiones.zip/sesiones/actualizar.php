<?php
include ('header.html')
?>
<h2>Actualizar de pedidos</h2>



<?php
include ('footer.html')
?>

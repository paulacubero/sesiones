<?php
include ('header.html');
require_once ("config.php");
echo  "<h2>Eliminar pedidos</h2>";
//var_dump($_GET['codigo']);
foreach ($conn->query('SELECT * from pedidos where id=' . $_GET["codigo"] . '') as $row) {
    //print_r($row);
    echo('<div class="card" style="width: 18rem;">');
    echo('<div class="card-body">');
    echo('<h5 class="card-title">' . $row["producto"] . '</h5>');
    echo('<p class="card-text">' . $row["fecha_pedido"] . '</p>');
    echo('<p class="card-text">' . $row["unidades"] . '</p>');
    echo('<p class="card-text">' . $row["id"] . '</p>');
    echo('<form action="" method="post">
        <button type="submit" class="btn btn-primary">Eliminar definitivamente</a>
    </form>');
    echo('</div>');
    echo('</div>');
}
if ($_SERVER['REQUEST_METHOD']=='POST'){
    $conn->query('DELETE FROM pedidos WHERE id='.$_GET['codigo'].';');
    header('location:consultar.php');
}
?>

<?php
include ('footer.html')
?>
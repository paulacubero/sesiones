<?php
include ('header.html');
require ("config.php");

 echo   "<h2>Listado de pedidos - consultar</h2>";
?>

 <table class="table table-success table-striped">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">FECHA DEL PEDIDO</th>
      <th scope="col">PRODUCTO</th>
      <th scope="col">UNIDADES</th>
      <th scope="col">ELIMINAR</th>
    </tr>
  </thead>

     <?php
try {
    foreach($conn->query('SELECT * from pedidos') as $row) {
        echo "<tr><td>".$row['id']."</td>";
        echo "<td>".$row['fecha_pedido']."</td>";
        echo "<td>".$row['producto']."</td>";
        echo "<td>".$row['unidades']."</td>";
        echo '<td><a href="eliminar.php?codigo='.$row["id"].'">
<ion-icon name="trash-bin-outline"></ion-icon></a>
</td>
</tr>';
    }
    $conn = null;
} catch (PDOException $e) {
    print "Error!: " . $e->getMessage() . "<br/>";
    die();
}

?>
     </table>
<?php
include ('footer.html')
?>


